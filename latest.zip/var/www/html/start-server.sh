java -Xmx2048M -jar /root/minecraft-server/server.jar
