apt install apache2
apt install php
mv panel/ports.conf /etc/apache2/
cp panel/* /var/www/html
systemctl restart apache2
